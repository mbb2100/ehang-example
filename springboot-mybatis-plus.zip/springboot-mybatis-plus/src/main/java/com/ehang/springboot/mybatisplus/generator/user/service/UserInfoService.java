package com.ehang.springboot.mybatisplus.generator.user.service;

import com.ehang.springboot.mybatisplus.generator.user.domain.UserInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 *
 */
public interface UserInfoService extends IService<UserInfo> {

}
