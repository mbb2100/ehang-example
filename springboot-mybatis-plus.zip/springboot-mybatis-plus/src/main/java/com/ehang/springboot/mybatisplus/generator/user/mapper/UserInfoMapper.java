package com.ehang.springboot.mybatisplus.generator.user.mapper;

import com.ehang.springboot.mybatisplus.generator.user.domain.UserInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Entity com.ehang.springboot.mybatisplus.generator.user.domain.UserInfo
 */
public interface UserInfoMapper extends BaseMapper<UserInfo> {

}




